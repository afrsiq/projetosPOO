﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceInvaders
{
    public class Mbappe
    {
        public PictureBox ImagemMbappe { get; private set; }
        private int velocidade = 5;

        public Mbappe (int x, int y, Form tela)
        {
            ImagemMbappe = new PictureBox();
            ImagemMbappe.BackColor = Color.Transparent;
            ImagemMbappe.Image = Properties.Resources.mbappe;
            ImagemMbappe.SizeMode = PictureBoxSizeMode.StretchImage;
            ImagemMbappe.Size = new Size(60, 70);
            ImagemMbappe.Location = new Point(x, y);

            tela.Controls.Add(ImagemMbappe);
        }

        public void MoverDireita()
        {
            ImagemMbappe.Location = new Point(ImagemMbappe.Location.X + velocidade, ImagemMbappe.Location.Y);
        }

        public void MoverEsquerda()
        {
            ImagemMbappe.Location = new Point(ImagemMbappe.Location.X - velocidade, ImagemMbappe.Location.Y);
        }

        public void MoverBaixo()
        {
            ImagemMbappe.Location = new Point(ImagemMbappe.Location.X, ImagemMbappe.Location.Y + 20);
        }

        public static Mbappe[,] MatrizMbappe = new Mbappe[3, 5];
        // 1 para a direita, -1 para a esquerda
        private static int direcaoGlobal = 1;
        public static void GerarFrota(Form telaJogo)
        {
            int espacoX = 80;
            int espacoY = 80;

            // Centraliza a matriz
            int largura = 380;
            int margemEsquerda = (telaJogo.ClientSize.Width - largura) / 2;
            int margemTopo = 50;

            for (int linha = 0; linha < 3; linha++)
            {
                for (int coluna = 0; coluna < 5; coluna++)
                {
                    int posicaoX = margemEsquerda + (coluna * espacoX);
                    int posicaoY = margemTopo + (linha  * espacoY);

                    MatrizMbappe[linha, coluna] = new Mbappe(posicaoX, posicaoY, telaJogo);
                }
            }
        }

        public static void Mover(int larguraTela)
        {
            bool bateuBorda = false;

            // Verifica se alguém vai bater na borda no próximo tick
            for (int linha = 0; linha < 3; linha++)
            {
                for (int coluna = 0;coluna < 5; coluna++)
                {
                    Mbappe inimigo = MatrizMbappe[linha, coluna];


                    if (inimigo != null && inimigo.ImagemMbappe.Visible)
                    {
                        // Se a posição atual + largura do inimigo + próximo passo passar da borda direita OU encostar na esquerda
                        if (inimigo.ImagemMbappe.Location.X + inimigo.ImagemMbappe.Width + (10 * direcaoGlobal) >= larguraTela ||
                            inimigo.ImagemMbappe.Location.X + (10 * direcaoGlobal) <= 0)
                        {
                            bateuBorda = true;
                            break;
                        }
                    }
                }
                if (bateuBorda) break;
            }

            // Todo o exército se move
            for (int linha = 0; linha < 3; linha++)
            {
                for (int coluna = 0; coluna < 5; coluna++)
                {
                    Mbappe inimigo = MatrizMbappe[linha, coluna];

                    if (inimigo != null && inimigo.ImagemMbappe.Visible)
                    {
                        if (bateuBorda) // Se bater na borda, todos descem
                        {
                            inimigo.MoverBaixo();
                        }
                        else // Se não, continuam andando para o lado correspondente
                        {
                            if (direcaoGlobal == 1)
                                inimigo.MoverDireita();
                            else
                                inimigo.MoverEsquerda();
                        }
                    }
                }
            }
            // Após bater na parede e descer, a direção inverte
            if (bateuBorda)
            {
                direcaoGlobal *= -1;
            }
        }
        public static bool VerificaMatrizDestruida()
        {
            for (int linha = 0; linha < 3; linha++)
            {
                for (int coluna = 0; coluna < 5; coluna++)
                {
                    if (MatrizMbappe[linha, coluna] != null && MatrizMbappe[linha, coluna].ImagemMbappe.Visible)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public static bool VerificaPassagem(int linhaDerrotaY)
        {
            for (int linha = 0;linha < 3; linha++)
            {
                for (int coluna = 0;coluna < 5; coluna++)
                {
                    Mbappe inimigo = MatrizMbappe[linha, coluna];

                    if (inimigo != null && inimigo.ImagemMbappe.Visible)
                    {
                        int bottomMbappe = inimigo.ImagemMbappe.Location.Y + inimigo.ImagemMbappe.Height;

                        if (bottomMbappe >= linhaDerrotaY)
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
    }
}