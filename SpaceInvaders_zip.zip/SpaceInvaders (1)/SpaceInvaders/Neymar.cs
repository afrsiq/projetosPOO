﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace SpaceInvaders
{
    public class Neymar
    {
        public PictureBox ImagemNeymar;
        private int limiteDireitoDaTela;
        private int delta = 10;
        private PictureBox[] iconesVida;

        public int Vidas { get; private set; }

        public Neymar(PictureBox pct, int larguraTela, PictureBox[] coracoes)
        {
            this.ImagemNeymar = pct;
            this.limiteDireitoDaTela = larguraTela;
            this.Vidas = 3;
            this.iconesVida = coracoes;
        }

        public void MoverEsquerda()
        {
            if (ImagemNeymar.Location.X - delta > 0)
                ImagemNeymar.Location = new Point(ImagemNeymar.Location.X - delta, ImagemNeymar.Location.Y);
            else
                ImagemNeymar.Location = new Point(0, ImagemNeymar.Location.Y);
        }

        public void MoverDireita()
        {
            if (ImagemNeymar.Location.X + delta + ImagemNeymar.Width < limiteDireitoDaTela)
                ImagemNeymar.Location = new Point(ImagemNeymar.Location.X + delta, ImagemNeymar.Location.Y);
            else
                ImagemNeymar.Location = new Point(limiteDireitoDaTela - ImagemNeymar.Width, ImagemNeymar.Location.Y);
        }

        public Point ObterPosicaoChute()
        {
            int xTiro = ImagemNeymar.Location.X + (ImagemNeymar.Width / 2);
            int yTiro = ImagemNeymar.Location.Y;
            return new Point(xTiro, yTiro);
        }

        public void PerderVida()
        {
            if (Vidas > 0)
            {
                Vidas--;
                iconesVida[Vidas].Visible = false;
            }

        }
    }
}