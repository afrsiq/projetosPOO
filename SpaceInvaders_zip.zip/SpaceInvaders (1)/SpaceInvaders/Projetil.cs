﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceInvaders
{
    public class Projetil
    {
        protected PictureBox pctBola;
        protected int delta = 10;
        protected GerenciadorColisoes gerenciador;

        private PictureBox pctGol;
        private Pontuacao placar;
        private Action Comemoracao;
        public Projetil(PictureBox bola, GerenciadorColisoes ger, PictureBox gol, Pontuacao pontos, Action comemoracao)
        {
            this.pctBola = bola;
            this.gerenciador = ger;
            this.pctGol = gol;
            this.placar = pontos;
            this.Comemoracao = comemoracao;
        }

        protected Projetil(PictureBox bola, GerenciadorColisoes ger)
        {
            this.pctBola = bola;
            this.gerenciador = ger;
        }

        public void Disparar(Point posicaoInicial)
           {
            pctBola.Location = new Point(
                posicaoInicial.X - (pctBola.Width / 2),
                posicaoInicial.Y - pctBola.Height
            );
            pctBola.Visible = true;

            Thread t = new Thread(() =>
            {
                for (; pctBola.Location.Y >= -pctBola.Height;)
                {
                    pctBola.Invoke((Action)(() => {
                        pctBola.Location = new Point(pctBola.Location.X, pctBola.Location.Y - delta);
                    }));

                    Thread.Sleep(100);

                    bool acertou = gerenciador.VerificarColisaoMbappe(pctBola);

                    if (acertou)
                    {
                        break; // Para a bola pois acertou um Mbappe
                    }
                    if (gerenciador.VerificarColisaoGol(pctBola, pctGol))
                    {
                        placar.BonusGol();
                        pctBola.Invoke(Comemoracao);
                        break;
                    }
                }

                pctBola.Invoke((Action)(() => {
                    pctBola.Visible = false; // Esconde o tiro
                }));
            });

            t.Start();
        }
    }
}