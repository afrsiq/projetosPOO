﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace SpaceInvaders
{
    internal class Jogo
    {
        public Neymar Jogador { get; private set; }
        public Projetil Tiro { get; private set; }
        public GerenciadorColisoes Juiz { get; private set; }
        public Pontuacao PlacarAtual {  get; private set; }

        private Form telaPrincipal;
        private PictureBox pctComemoracao;
        private Panel panelFimJogo;
        private Label lblPontuacao;
        private PictureBox pctGol;
        private Label lblResultado;
        private Panel linhaDefesa;

        public Jogo(Form tela, PictureBox pctNeymar, PictureBox pctBola, PictureBox pctGol, PictureBox[] coracoes, PictureBox pctComemoracao, Panel panelFim, Label lblPontos, Label lblResultado, Panel linhaDefesa)
        {
            this.telaPrincipal = tela;
            this.pctComemoracao = pctComemoracao;
            this.panelFimJogo = panelFim;
            this.pctGol = pctGol;
            this.lblPontuacao = lblPontos;
            this.lblResultado = lblResultado;
            this.linhaDefesa = linhaDefesa;

            this.PlacarAtual = new Pontuacao();
            this.Juiz = new GerenciadorColisoes();
            this.Jogador = new Neymar(pctNeymar, telaPrincipal.ClientSize.Width, coracoes);
            Tiro = new Projetil(pctBola, Juiz, pctGol, PlacarAtual, MostrarComemoracao);

            Mbappe.GerarFrota(telaPrincipal);
        }

        public void Atualizar(Timer relogioJogo, Timer relogioTirosInimigos)
        {
            //Move a matriz
            Mbappe.Mover(telaPrincipal.ClientSize.Width);

            if (Mbappe.VerificaMatrizDestruida())
            {
                relogioJogo.Stop();
                relogioTirosInimigos.Stop();

                PlacarAtual.CalcularPontos();

                lblResultado.Text = "Vitória";
                lblResultado.ForeColor = Color.Green;

                lblPontuacao.Visible = true;
                lblPontuacao.Text = "Pontuação: " + PlacarAtual.PontosTotais;

                panelFimJogo.BackgroundImage = Properties.Resources.taca_copa;
                panelFimJogo.BackgroundImageLayout = ImageLayout.Stretch;

                panelFimJogo.Visible = true;
                panelFimJogo.BringToFront();
                return;
            }

            int linhaDerrota = linhaDefesa.Location.Y;

            if (Jogador.Vidas <= 0 || Mbappe.VerificaPassagem(linhaDerrota))
            {
                relogioJogo.Stop();
                relogioTirosInimigos.Stop();

                lblResultado.Text = "Derrota";
                lblResultado.ForeColor = Color.Red;

                lblPontuacao.Visible = false;

                panelFimJogo.BackgroundImage = Properties.Resources.franca_taca;
                panelFimJogo.BackgroundImageLayout = ImageLayout.Stretch;

                panelFimJogo.Visible = true;
                panelFimJogo.BringToFront();
                return;
            }
        }
        public async void MostrarComemoracao()
        {
            pctComemoracao.Visible = true; // Mostra a imagem
            await Task.Delay(2000); // Espera 2 segundos
            pctComemoracao.Visible = false; // Esconde a imagem
        }

        public void GerenciarTiroInimigo(PictureBox pctTiroMbappe, int alturaTela)
        {
            // Se tiver um disparo na tela, nao  solta outro
            if (pctTiroMbappe.Visible == true) return;

            // Sorteia uma posicao aleatoria
            Random sorteio = new Random();
            int linha = sorteio.Next(0, 3);
            int coluna = sorteio.Next(0, 5);

            // Seleciona o mbappe correspondente na matriz
            Mbappe atirador = Mbappe.MatrizMbappe[linha, coluna];

            // Atira se o inimigo sorteado existir e estiver vivo
            if (atirador != null && atirador.ImagemMbappe.Visible)
            {
                // Cria o projétil inimigo
                ProjetilInimigo ataque = new ProjetilInimigo(pctTiroMbappe, Juiz, alturaTela);

                // Calcula de onde o tiro vai sair
                Point localDoTiro = new Point(
                    atirador.ImagemMbappe.Location.X + (atirador.ImagemMbappe.Width / 2),
                    atirador.ImagemMbappe.Location.Y + atirador.ImagemMbappe.Height
                );

                ataque.Disparar(localDoTiro, Jogador);
            }
        }
    }
}