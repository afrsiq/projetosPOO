﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace SpaceInvaders
{
    public class Pontuacao
    {
        private Stopwatch cronometro;
        public int PontosTotais { get; private set; }

        public Pontuacao()
        {
            cronometro = new Stopwatch();
            cronometro.Start();
            PontosTotais = 0;
        }

        public void CalcularPontos()
        {
            cronometro.Stop();

            long tempoConclusao = cronometro.ElapsedMilliseconds / 1000;

            int pontosInicial = 5000; // Começa com 5000 pontos
            int penalidadeTempo = (int)(tempoConclusao * 50); // Perde 50 pontos por segundo decorrido
            int pontosFinal = pontosInicial - penalidadeTempo;

            // Nao pode ser negativo
            if (pontosFinal < 0)
            {
                pontosFinal = 0;
            }

            PontosTotais += pontosFinal;
        }

        public void BonusGol()
        {
            PontosTotais += 1000; // Ganha 100 pontos sempre que acertar o gol
        }
    }
}