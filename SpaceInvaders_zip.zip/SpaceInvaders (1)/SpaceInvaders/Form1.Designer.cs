﻿namespace SpaceInvaders
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pctNeymar = new System.Windows.Forms.PictureBox();
            this.pctBola = new System.Windows.Forms.PictureBox();
            this.pctGol = new System.Windows.Forms.PictureBox();
            this.pctCoracao1 = new System.Windows.Forms.PictureBox();
            this.pctCoracao2 = new System.Windows.Forms.PictureBox();
            this.pctCoracao3 = new System.Windows.Forms.PictureBox();
            this.panelFimJogo = new System.Windows.Forms.Panel();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnReiniciar = new System.Windows.Forms.Button();
            this.lblPontuacao = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pctComemoracao = new System.Windows.Forms.PictureBox();
            this.pctTiroMbappe = new System.Windows.Forms.PictureBox();
            this.linhaDefesa = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pctNeymar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctBola)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctGol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctCoracao1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctCoracao2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctCoracao3)).BeginInit();
            this.panelFimJogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctComemoracao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctTiroMbappe)).BeginInit();
            this.SuspendLayout();
            // 
            // pctNeymar
            // 
            this.pctNeymar.BackColor = System.Drawing.Color.Transparent;
            this.pctNeymar.Image = global::SpaceInvaders.Properties.Resources.neymarsniper;
            this.pctNeymar.Location = new System.Drawing.Point(360, 470);
            this.pctNeymar.Name = "pctNeymar";
            this.pctNeymar.Size = new System.Drawing.Size(80, 90);
            this.pctNeymar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pctNeymar.TabIndex = 1;
            this.pctNeymar.TabStop = false;
            // 
            // pctBola
            // 
            this.pctBola.BackColor = System.Drawing.Color.Transparent;
            this.pctBola.Image = global::SpaceInvaders.Properties.Resources.ball;
            this.pctBola.Location = new System.Drawing.Point(387, 283);
            this.pctBola.Name = "pctBola";
            this.pctBola.Size = new System.Drawing.Size(25, 25);
            this.pctBola.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pctBola.TabIndex = 0;
            this.pctBola.TabStop = false;
            // 
            // pctGol
            // 
            this.pctGol.BackColor = System.Drawing.Color.Transparent;
            this.pctGol.Image = global::SpaceInvaders.Properties.Resources.golpng;
            this.pctGol.Location = new System.Drawing.Point(310, 10);
            this.pctGol.Name = "pctGol";
            this.pctGol.Size = new System.Drawing.Size(180, 60);
            this.pctGol.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pctGol.TabIndex = 2;
            this.pctGol.TabStop = false;
            // 
            // pctCoracao1
            // 
            this.pctCoracao1.BackColor = System.Drawing.Color.Transparent;
            this.pctCoracao1.Image = global::SpaceInvaders.Properties.Resources._190_1905759_minecraft_heart_8_bit_heart_transparent;
            this.pctCoracao1.Location = new System.Drawing.Point(10, 10);
            this.pctCoracao1.Name = "pctCoracao1";
            this.pctCoracao1.Size = new System.Drawing.Size(30, 30);
            this.pctCoracao1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pctCoracao1.TabIndex = 3;
            this.pctCoracao1.TabStop = false;
            // 
            // pctCoracao2
            // 
            this.pctCoracao2.BackColor = System.Drawing.Color.Transparent;
            this.pctCoracao2.Image = global::SpaceInvaders.Properties.Resources._190_1905759_minecraft_heart_8_bit_heart_transparent;
            this.pctCoracao2.Location = new System.Drawing.Point(45, 10);
            this.pctCoracao2.Name = "pctCoracao2";
            this.pctCoracao2.Size = new System.Drawing.Size(30, 30);
            this.pctCoracao2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pctCoracao2.TabIndex = 4;
            this.pctCoracao2.TabStop = false;
            // 
            // pctCoracao3
            // 
            this.pctCoracao3.BackColor = System.Drawing.Color.Transparent;
            this.pctCoracao3.Image = global::SpaceInvaders.Properties.Resources._190_1905759_minecraft_heart_8_bit_heart_transparent;
            this.pctCoracao3.Location = new System.Drawing.Point(80, 10);
            this.pctCoracao3.Name = "pctCoracao3";
            this.pctCoracao3.Size = new System.Drawing.Size(30, 30);
            this.pctCoracao3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pctCoracao3.TabIndex = 5;
            this.pctCoracao3.TabStop = false;
            // 
            // panelFimJogo
            // 
            this.panelFimJogo.AutoSize = true;
            this.panelFimJogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelFimJogo.Controls.Add(this.btnSair);
            this.panelFimJogo.Controls.Add(this.btnReiniciar);
            this.panelFimJogo.Controls.Add(this.lblPontuacao);
            this.panelFimJogo.Controls.Add(this.lblResultado);
            this.panelFimJogo.Location = new System.Drawing.Point(200, 150);
            this.panelFimJogo.Name = "panelFimJogo";
            this.panelFimJogo.Size = new System.Drawing.Size(403, 300);
            this.panelFimJogo.TabIndex = 6;
            this.panelFimJogo.Visible = false;
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.SeaGreen;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.White;
            this.btnSair.Location = new System.Drawing.Point(220, 220);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(140, 45);
            this.btnSair.TabIndex = 3;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnReiniciar
            // 
            this.btnReiniciar.BackColor = System.Drawing.Color.IndianRed;
            this.btnReiniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReiniciar.ForeColor = System.Drawing.Color.White;
            this.btnReiniciar.Location = new System.Drawing.Point(40, 220);
            this.btnReiniciar.Name = "btnReiniciar";
            this.btnReiniciar.Size = new System.Drawing.Size(140, 45);
            this.btnReiniciar.TabIndex = 2;
            this.btnReiniciar.Text = "Reiniciar";
            this.btnReiniciar.UseVisualStyleBackColor = false;
            this.btnReiniciar.Click += new System.EventHandler(this.btnReiniciar_Click);
            // 
            // lblPontuacao
            // 
            this.lblPontuacao.BackColor = System.Drawing.Color.Transparent;
            this.lblPontuacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPontuacao.Location = new System.Drawing.Point(0, 100);
            this.lblPontuacao.Name = "lblPontuacao";
            this.lblPontuacao.Size = new System.Drawing.Size(400, 40);
            this.lblPontuacao.TabIndex = 1;
            this.lblPontuacao.Text = "Pontuação: 0";
            this.lblPontuacao.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblResultado
            // 
            this.lblResultado.BackColor = System.Drawing.Color.Transparent;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(0, 20);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(400, 60);
            this.lblResultado.TabIndex = 0;
            this.lblResultado.Text = "Vitória!";
            this.lblResultado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pctComemoracao
            // 
            this.pctComemoracao.BackColor = System.Drawing.Color.Transparent;
            this.pctComemoracao.Image = global::SpaceInvaders.Properties.Resources.edited_photo__2_;
            this.pctComemoracao.Location = new System.Drawing.Point(584, -6);
            this.pctComemoracao.Name = "pctComemoracao";
            this.pctComemoracao.Size = new System.Drawing.Size(150, 150);
            this.pctComemoracao.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pctComemoracao.TabIndex = 7;
            this.pctComemoracao.TabStop = false;
            this.pctComemoracao.Visible = false;
            // 
            // pctTiroMbappe
            // 
            this.pctTiroMbappe.BackColor = System.Drawing.Color.Transparent;
            this.pctTiroMbappe.Image = global::SpaceInvaders.Properties.Resources.pngtree_red_and_black_soccer_ball_icon_illustration_vector_png_image_18495631__1_1;
            this.pctTiroMbappe.Location = new System.Drawing.Point(617, 209);
            this.pctTiroMbappe.Name = "pctTiroMbappe";
            this.pctTiroMbappe.Size = new System.Drawing.Size(25, 25);
            this.pctTiroMbappe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pctTiroMbappe.TabIndex = 8;
            this.pctTiroMbappe.TabStop = false;
            this.pctTiroMbappe.Visible = false;
            // 
            // linhaDefesa
            // 
            this.linhaDefesa.Location = new System.Drawing.Point(0, 460);
            this.linhaDefesa.Name = "linhaDefesa";
            this.linhaDefesa.Size = new System.Drawing.Size(800, 3);
            this.linhaDefesa.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = global::SpaceInvaders.Properties.Resources.mbape_jpg;
            this.ClientSize = new System.Drawing.Size(782, 553);
            this.Controls.Add(this.linhaDefesa);
            this.Controls.Add(this.pctTiroMbappe);
            this.Controls.Add(this.panelFimJogo);
            this.Controls.Add(this.pctCoracao3);
            this.Controls.Add(this.pctCoracao2);
            this.Controls.Add(this.pctCoracao1);
            this.Controls.Add(this.pctGol);
            this.Controls.Add(this.pctNeymar);
            this.Controls.Add(this.pctBola);
            this.Controls.Add(this.pctComemoracao);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pctNeymar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctBola)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctGol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctCoracao1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctCoracao2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctCoracao3)).EndInit();
            this.panelFimJogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pctComemoracao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctTiroMbappe)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pctBola;
        private System.Windows.Forms.PictureBox pctNeymar;
        private System.Windows.Forms.PictureBox pctGol;
        private System.Windows.Forms.PictureBox pctCoracao1;
        private System.Windows.Forms.PictureBox pctCoracao2;
        private System.Windows.Forms.PictureBox pctCoracao3;
        private System.Windows.Forms.Panel panelFimJogo;
        private System.Windows.Forms.PictureBox pctComemoracao;
        private System.Windows.Forms.Label lblPontuacao;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnReiniciar;
        private System.Windows.Forms.PictureBox pctTiroMbappe;
        private System.Windows.Forms.Panel linhaDefesa;
    }
}

