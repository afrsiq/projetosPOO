﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceInvaders
{
    public class ProjetilInimigo : Projetil
    {
        private int limiteChao;

        public ProjetilInimigo(PictureBox bola, GerenciadorColisoes ger, int limiteTela) : base(bola,ger)
        {
            this.limiteChao = limiteTela;
            this.delta = 15;
        }

        public void Disparar(Point posicaoInicial, Neymar jogador)
        {
            pctBola.Location = new Point(posicaoInicial.X - (pctBola.Width / 2), posicaoInicial.Y);
            pctBola.Visible = true;

            Thread t = new Thread(() =>
            {
                // Enquanto for menor que o chão da tela
                for (; pctBola.Location.Y <= limiteChao;)
                {
                    pctBola.Invoke((Action)(() => {
                        // Soma o delta para a bola descer
                        pctBola.Location = new Point(pctBola.Location.X, pctBola.Location.Y + delta);
                    }));

                    Thread.Sleep(100);

                    bool acertou = gerenciador.VerificarColisaoNey(pctBola, jogador.ImagemNeymar);

                    if (acertou)
                    {
                        pctBola.Invoke((Action)(() => {
                            jogador.PerderVida();
                        }));
                        break;
                    }
                }

                pctBola.Invoke((Action)(() => {
                    pctBola.Visible = false; // Esconde o tiro
                }));
            });

            t.Start();
        }
    }
}