﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceInvaders
{
    public class GerenciadorColisoes
    {
        public bool VerificarColisaoMbappe(PictureBox tiro)
        {
            int xTiro = tiro.Location.X + (tiro.Width / 2);
            int yTiro = tiro.Location.Y;

            // Percorre a matriz
            for (int linha = 0; linha < 3; linha++)
            {
                for (int coluna = 0; coluna < 5; coluna++)
                {
                    Mbappe inimigo = Mbappe.MatrizMbappe[linha, coluna];

                    // Verifica se o Mbappe existe e se ainda não foi destruído
                    if (inimigo != null && inimigo.ImagemMbappe.Visible)
                    {
                        if ((xTiro >= inimigo.ImagemMbappe.Location.X) &&
                            (xTiro <= inimigo.ImagemMbappe.Location.X + inimigo.ImagemMbappe.Width) &&
                            (yTiro <= inimigo.ImagemMbappe.Location.Y + inimigo.ImagemMbappe.Height))
                        {
                            // Esconde o Mbappe
                            inimigo.ImagemMbappe.Invoke((System.Action)(() =>
                            {
                                inimigo.ImagemMbappe.Visible = false;
                            }));

                            return true; // Acertou
                        }
                    }
                }
            }
            return false; // Errou
        }
        public bool VerificarColisaoGol(PictureBox tiro, PictureBox gol)
        {
            int xTiro = tiro.Location.X + (tiro.Width / 2);
            int yTiro = tiro.Location.Y;

            if ((xTiro >= gol.Location.X) && (xTiro <= gol.Location.X + gol.Width) && (yTiro <= gol.Location.Y + gol.Height))
            {
                return true;
            }
            return false;
        }
        public bool VerificarColisaoNey(PictureBox tiro, PictureBox ney)
        {
            int xTiro = tiro.Location.X + (tiro.Width / 2);
            int yTiro = tiro.Location.Y + tiro.Height;

            if ((xTiro >= ney.Location.X) && (xTiro <= ney.Location.X + ney.Width) && (yTiro >= ney.Location.Y) && (yTiro <= ney.Location.Y + ney.Height))
            {
                return true;
            }
            return false;
        }
    }
}