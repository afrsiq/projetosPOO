﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceInvaders
{
    public partial class Form1 : Form
    {
        private Jogo partidaAtual;
        private System.Windows.Forms.Timer relogioJogo; // Para fazer a matriz se mover
        private System.Windows.Forms.Timer relogioTirosInimigos;
        public Form1()
        {
            InitializeComponent();

            this.DoubleBuffered = true;

            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown;

            pctBola.Visible = false;
            panelFimJogo.Visible = false; // Painel invisível ao abrir a tela

            PictureBox[] minhasVidas = { pctCoracao1, pctCoracao2, pctCoracao3 };

            partidaAtual = new Jogo(this, pctNeymar, pctBola, pctGol, minhasVidas, pctComemoracao, panelFimJogo, lblPontuacao, lblResultado, linhaDefesa);

            relogioJogo = new System.Windows.Forms.Timer();
            relogioJogo.Interval = 100;
            relogioJogo.Tick += RelogioJogo_Tick;
            relogioJogo.Start();

            relogioTirosInimigos = new System.Windows.Forms.Timer();
            relogioTirosInimigos.Interval = 1500;
            relogioTirosInimigos.Tick += RelogioTirosInimigos_Tick;
            relogioTirosInimigos.Start();
        }

        private void RelogioJogo_Tick(object sender, EventArgs e)
        {
            partidaAtual.Atualizar(relogioJogo, relogioTirosInimigos);
        }

        private void RelogioTirosInimigos_Tick(object sender, EventArgs e)
        {
            partidaAtual.GerenciarTiroInimigo(pctTiroMbappe, this.ClientSize.Height);
            
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (panelFimJogo.Visible) return;

            switch (e.KeyCode)
            {
                case Keys.A:
                case Keys.Left:
                    partidaAtual.Jogador.MoverEsquerda();
                    break;

                case Keys.D:
                case Keys.Right:
                    partidaAtual.Jogador.MoverDireita();
                    break;

                case Keys.Space:
                    Point posicaoTiro = partidaAtual.Jogador.ObterPosicaoChute();
                    partidaAtual.Tiro.Disparar(posicaoTiro);
                    break;
            }
        }

        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}