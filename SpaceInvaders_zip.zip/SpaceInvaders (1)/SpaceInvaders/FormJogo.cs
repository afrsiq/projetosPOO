using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceInvaders
{
    public partial class FormJogo : Form
    {
        public FormJogo()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_Iniciar_Click(object sender, EventArgs e)
        {
            Form1 telaPrincipal = new Form1();

            telaPrincipal.FormClosed += (s, args) => this.Close();

            // Exibe a tela do jogo
            telaPrincipal.Show();

            // Esconde a tela de menu atual
            this.Hide();
        }
    }
}